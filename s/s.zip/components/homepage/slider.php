<div class="slider">
    <div class="slide">
        
    </div>
</div>