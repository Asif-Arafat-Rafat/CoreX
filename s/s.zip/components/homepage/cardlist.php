<div class="cardlist">
<div class="listimage">
        <img src="./image/keyboard1.png" alt="">
</div>
<div class="infocard">
        <div class="reviews">
                <?php
                $vote=22;
                include "./components/homepage/noneditable-rating.php";
                ?>
                <div class="soldInfo"><p>66 sold</p></div>
        </div>
        <div class="productName"><p>CSX RGB Backlit Ultra Compact Mini Mechanical Keyboard</p> </div>
        <div class="restInfo">
                <div class="extraInfo"> 
                        <div class="productPrice"><p>BDT2000</p></div>
                        <div class="productVariant"><p>3 Variants</p></div>
                </div>
                <div class="addToCart"><h1><i class="fa-solid fa-cart-plus"></i></h1></div>
        </div>

        
    </div>
</div>