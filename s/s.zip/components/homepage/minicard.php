<div class="outer-card">
        <div class="corner-ribbon">Super Deal</div>
        <div class="inner-card">
            <img src="./image/keyboard1.png" alt="Product" class="product-img">
            <div class="ribbonbg"></div>
            <div class="bottom-ribbon">20% OFF</div>
            <button class="details-btn-hover">Click to see Details</button>
        </div>
    </div>