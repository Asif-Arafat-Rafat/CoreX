<div class="category">
    <h1>Category</h1>
    <div class="Categories">
        <a href="./products.php?category=Mouse" class="cate">
            <img src="./image/Categories/mouse.png" alt="">
            <h3>Mouse</h3>
        </a>
        <a href="./products.php?category=Keyboard" class="cate">
            <img src="./image/Categories/keyboard.png" alt="">
            <h3>Keyboard</h3>
        </a>
        <a href="./products.php?category=HeadPhone" class="cate">
            <img src="./image/Categories/headset.png" alt="">
            <h3>HeadPhone</h3>
        </a>
        <a href="./products.php?category=TWS" class="cate">
            <img src="./image/Categories/tws.png" alt="">
            <h3>TWS</h3>
        </a>
        <a href="./products.php?category=Fan" class="cate">
            <img src="./image/Categories/fan.png" alt="">
            <h3>Fan</h3>
        </a>
        <a href="./products.php?category=Speaker" class="cate">
            <img src="./image/Categories/speaker.png" alt="">
            <h3>Speaker</h3>
        </a>
        <a href="./products.php?category=Router" class="cate">
            <img src="./image/Categories/router.png" alt="">
            <h3>Router</h3>
        </a>
    </div>
</div>
