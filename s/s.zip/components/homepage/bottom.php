    
</body>
<script src="./js/nav.js"></script>
<script src="./js/form.js"></script>
<script src="./js/ajax-add-to-cart.js"></script>
<script src="./js/carousel.js"></script>
<script src="./js/cart.js"></script>
<script src="https://kit.fontawesome.com/318799c1ce.js" crossorigin="anonymous"></script>
</html>