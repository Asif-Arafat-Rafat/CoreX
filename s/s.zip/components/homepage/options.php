<div class="optionBox">
    <button>Info</button>
    <button>Logout</button>
</div>